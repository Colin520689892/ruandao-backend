document.querySelectorAll('.contact-button').forEach(button => {
    button.addEventListener('click', function() {
        alert('Contacting ' + this.parentNode.querySelector('h2').textContent);
    });
});